---
name: resume-attachment-manager
description: Retrieve and verify the latest role-appropriate resume PDF from M. Ahmad's GitHub resume repository, then attach it to an approved Gmail application draft when an attachment-capable connector or MCP tool is available. Use when a job application email needs the latest resume, when the user asks to attach a CV from the resume repo, or when another skill needs a verified resume file. Never claim an attachment was added unless the mail tool confirms it, and never send automatically.
---

# Resume Attachment Manager

Use this skill as the file and attachment stage of a job application workflow. It does not replace the duplicate-application check.

## Non-negotiable rules

- Never run before the job application workflow has resolved the role and completed its Gmail duplicate check.
- Never claim that a resume is attached unless the mail tool returns confirmation of the attachment name.
- Never send an email automatically.
- Create an attachment-ready Gmail draft only after the user approves the email text or explicitly asks to save it as a draft.
- If no attachment-capable Gmail tool is available, stop and explain the limitation. Do not create a misleading draft that says the resume is attached.
- Do not attach a repository source file, HTML page, JSON file, or ZIP in place of a PDF.

## 1. Resolve the resume source

Use the configuration in `references/resume-source.md`.

Default repository:

`mahmadfareedi/resume`

Default branch:

`master`

The repository generates resume PDFs from current source data. Prefer a PDF generated from the latest commit instead of choosing a stale PDF by filename or upload date.

## 2. Select the resume variant

Choose the closest supported variant from the job title and requirements:

- `senior_analyst`: Senior Data Analyst, Data Analyst, BI Analyst, Reporting Analyst, Product Analyst, or closely related analytics roles
- `analyst_engineer`: Data Engineer, Analytics Engineer, BI Engineer, Data Platform, ETL, or combined analyst and engineering roles
- `analytics_manager`: Analytics Manager, BI Manager, Analytics Lead, Head of Analytics, or roles emphasizing team ownership and analytics strategy

When two variants are equally plausible, ask the user which one to use. Do not guess when the choice could materially affect the application.

## 3. Retrieve the latest PDF

Prefer an installed attachment MCP or connector that implements the contract in `references/mcp-contract.md`.

The retrieval tool must:

1. Resolve the latest commit on the configured branch.
2. Generate or fetch the selected PDF from that exact commit.
3. Return a real file reference or mounted file path, not only a URL.
4. Return the filename, MIME type, file size, variant, source commit SHA, and checksum when available.

Accept only:

- MIME type `application/pdf`
- A filename ending in `.pdf`
- A non-empty file
- A source commit matching the latest resolved commit unless the user explicitly selected an older version

If retrieval fails, report the repository, branch, variant, and failure reason. Do not proceed to the attachment step.

## 4. Present the selected resume

Before creating a Gmail draft, state:

- Selected resume variant
- PDF filename
- Source repository and branch
- Source commit short SHA
- File size when available

When the user has not yet approved the application email, provide the resume details but do not create a draft.

## 5. Create a Gmail draft with the PDF attached

Use an attachment-capable Gmail connector or MCP tool. The tool must accept a file reference or local path as an attachment.

Before calling it, verify:

1. Recipient email is known.
2. Subject and body are the approved versions.
3. The resume PDF passed the checks above.
4. The user explicitly asked to save or prepare the Gmail draft.

After creation, verify the result includes:

- Gmail draft identifier
- Attachment filename matching the selected PDF
- A Gmail display URL when available

Respond with:

`The Gmail draft is ready with <filename> attached. Please review it in Gmail before sending.`

Do not say it was attached if the tool response does not confirm the attachment.

## 6. Send only after separate confirmation

Treat sending as a separate action. Send only when the user explicitly asks to send the approved draft after attachment verification.

If the user says only `write the email`, `apply`, `prepare it`, or `draft it`, do not send.

## Fallback when attachment tools are unavailable

Use this exact behavior:

`I retrieved the latest resume details, but the connected Gmail tool cannot add file attachments. I have not created a misleading draft. An attachment-capable Gmail MCP or connector is required to create a one-click draft with the resume included.`

Then provide the selected resume filename and source commit. Do not claim the workflow is complete.
