# Resume Source Configuration

## Repository

- Repository: `mahmadfareedi/resume`
- Default branch: `master`
- Source type: generated PDF from current repository content

## Supported variants

| Variant | Resume label | Typical roles |
|---|---|---|
| `senior_analyst` | Senior Data Analyst | Senior Data Analyst, Data Analyst, BI Analyst, Reporting Analyst, Product Analyst |
| `analyst_engineer` | Data Analyst and Engineer | Data Engineer, Analytics Engineer, BI Engineer, ETL, Data Platform |
| `analytics_manager` | Analytics Manager | Analytics Manager, BI Manager, Analytics Lead, Head of Analytics |

## Preferred filenames

- `Muhammad_Ahmad_Senior_Data_Analyst.pdf`
- `Muhammad_Ahmad_Data_Analyst_and_Engineer.pdf`
- `Muhammad_Ahmad_Analytics_Manager.pdf`

## Freshness rule

Resolve the latest commit on `master` at execution time. Generate or retrieve the PDF from that commit. Do not choose a file merely because its filename contains `latest` or because its upload timestamp is recent.

## Deployment options

Use the first available option:

1. An MCP tool that checks out the latest repository commit and generates the PDF.
2. A trusted deployed resume service that exposes the repository's PDF route and reports the source commit.
3. A GitHub Actions output or release asset generated from the latest commit.

Do not use an unverified public URL when it cannot prove which commit produced the PDF.
