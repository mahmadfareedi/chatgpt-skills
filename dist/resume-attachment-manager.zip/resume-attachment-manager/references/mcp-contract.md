# Attachment MCP Contract

A Skill can define the workflow, but it cannot add binary attachment support to a mail connector. For the complete workflow, install an MCP or connector exposing equivalent tools.

## Tool 1: get_latest_resume_pdf

Purpose: Generate or retrieve a current resume PDF from GitHub and return a usable file reference.

Suggested input:

```json
{
  "repository_full_name": "mahmadfareedi/resume",
  "ref": "master",
  "variant": "senior_analyst"
}
```

Required output fields:

```json
{
  "file": "<connector file reference or mounted local path>",
  "filename": "Muhammad_Ahmad_Senior_Data_Analyst.pdf",
  "mime_type": "application/pdf",
  "size_bytes": 123456,
  "variant": "senior_analyst",
  "source_commit_sha": "<full sha>",
  "sha256": "<file checksum>",
  "generated_at": "<ISO 8601 timestamp>"
}
```

Recommended implementation:

1. Resolve the latest commit on the configured ref through the GitHub API.
2. Check out or download that exact commit.
3. Install or reuse the repository runtime and Playwright browser cache.
4. Generate the requested PDF through the repository's PDF route or generator.
5. Store the PDF in temporary connector storage.
6. Return a connector file reference or mounted path.

## Tool 2: create_gmail_draft_with_attachments

Purpose: Create a Gmail draft with one or more real file attachments.

Suggested input:

```json
{
  "to": "talent@example.com",
  "subject": "Application for Senior Data Analyst",
  "body": "<approved email body>",
  "attachments": ["<file reference from get_latest_resume_pdf>"]
}
```

Required output fields:

```json
{
  "draft_id": "<gmail draft id>",
  "display_url": "<open in Gmail URL>",
  "attachment_names": ["Muhammad_Ahmad_Senior_Data_Analyst.pdf"]
}
```

The implementation should use Gmail's multipart MIME draft creation flow and must not send the message.

## Optional Tool 3: send_gmail_draft

Purpose: Send an already reviewed draft only after a separate explicit user instruction.

Required input:

```json
{
  "draft_id": "<reviewed draft id>"
}
```

Do not combine draft creation and sending into one automatic action.

## Security requirements

- Use OAuth with the minimum GitHub and Gmail scopes required.
- Never log email bodies, OAuth tokens, private repository contents, or attachment bytes.
- Store temporary PDFs only as long as needed.
- Reject files that are not PDFs or exceed the configured size limit.
- Require explicit user confirmation before sending.
