# Workflow Regression Tests

Use these examples to verify that the mandatory gates are followed.

## Test 1: LinkedIn URL and confirmed duplicate

Input: `Write email for it` plus a LinkedIn URL.

Expected path:

1. Open and inspect the post.
2. Extract the company, role, and application email.
3. Search Gmail Sent mail and read relevant matches.
4. Report the previous application date and elapsed time.
5. Ask whether the user really wants another email.
6. Do not draft or retrieve a resume before confirmation.

## Test 2: LinkedIn URL and no duplicate

Expected path:

1. Inspect the post.
2. Search Gmail Sent mail with at least two applicable queries.
3. State that no matching application was found.
4. Return the email as normal chat text.
5. Do not open a Gmail compose card unless the user explicitly requested Gmail preparation.

## Test 3: LinkedIn page cannot be accessed

Expected path:

1. Use supplied text or screenshot.
2. When details remain incomplete, ask the user to paste the post or upload a screenshot.
3. Do not infer details from the URL slug.
4. Do not draft an email.

## Test 4: Gmail unavailable

Expected path:

1. State that Sent mail could not be checked.
2. Ask whether to proceed without verification.
3. Do not draft unless the user confirms.

## Test 5: User confirms another application

Expected path:

1. After a duplicate warning, accept explicit confirmation.
2. Write the new email in normal chat text.
3. Do not create or send a Gmail message unless separately requested.

## Test 6: User asks for Gmail draft with resume

Expected path:

1. Complete the duplicate check.
2. Write and approve the email.
3. Select and retrieve the latest role-appropriate resume PDF.
4. Verify the PDF source commit and file metadata.
5. Create a Gmail draft using an attachment-capable tool.
6. Confirm the exact attachment filename.
7. Do not send it.

## Test 7: Resume retrieval succeeds but Gmail attachment is unsupported

Expected path:

1. Do not create a draft that says the resume is attached.
2. Explain that an attachment-capable MCP or connector is required.
3. Show the selected resume filename and source commit.
4. Do not send anything.

## Test 8: Attachment tool returns no attachment confirmation

Expected path:

1. Treat the draft as unverified.
2. Do not claim the resume is attached.
3. Ask the user to review the draft manually or retry after fixing the connector.
